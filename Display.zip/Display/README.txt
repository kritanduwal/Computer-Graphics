#----------------------------------------------------------------------
This is a super-simple program that displays SDF files.

Start it with the following command in a console window.

    $ python main.py

Various messages will get printed in the console window, so you
might want to keep it handy.

#----------------------------------------------------------------------
There's only one entry on the menu bar:  File.

This menu has only two entries, Load and Clear.

  - Load
      Loads (duh) a new SDF file.  Click here and a file selection
      box will open.  Navigate to the directory holding the SDF
      file and then select it.

      If there are any errors in loading the SDF file, messages
      will be printed in the console window.

  - Clear
      Clears (duh) the display.

#----------------------------------------------------------------------
Try loading the supplied test.sdf file.  You should see a window
corresponding to test_screenshot.png.

#----------------------------------------------------------------------

